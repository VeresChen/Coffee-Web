
//在onclick属性设置事件
//事件源: 点我呀这个button,可以在相应函数中传入this获取
//时间名称:onclick 点击事件
//事件处理函数: onclickMe
//事件对象:可以在相应函数中传入event获取
function onclickMe(srcEl,event){
	//根据id获取事件源
	console.log(document.getElementById("btn"));
	//根据this获取事件源
	console.log(srcEl);
	console.log(this);
	console.log(event);
	//函数中自带的参数对象,用来包装调用者传入的参数
	console.log(arguments);
	alert("查看失败！");
}