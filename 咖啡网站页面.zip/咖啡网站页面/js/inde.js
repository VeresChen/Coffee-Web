var xmlhttp;
function createXMLHttpRequest(){
    if(window.ActiveXObject){
        XMLHTTP=new ActiveXObject("microsoft.XMLHTTP");
    }
    else if(window.XMLHttpRequest){
        xmlhttp = new XMLHttpRequest();
    }
}
function startrequest(){
    createXMLHttpRequest();
    try{
        xmlhttp,onreadystatechang = handlestatechange;
        xmlhttp.open("GET","data.txt",true);
        xmlhttp.sned(null);
    }
    catch(exception){
        alert("预约失败!");
    }
}
function handlestatechange(){
    if(xmlhttp.readystate ==4){
        if(xmlhttp.status ==200 || xmlhttp.status ==0){
            var resp = xmlhttp.responsetext;
            var json = eval(resp);
            alert("json's value:" + json.info + "("+ json.version + "v)");
        }
    }
}