$(function () {
  $("#bn").on("click", function () {
    var A = $("input[name=A]").val();// 获取名为.....的输入框的值
    var B = $("input[name=B").val();
    var C = $("input[name=C").val();
    var D = $("input[name=D").val();
    console.log(A, B, C, D);// 打印A、B、C、D的值

    // 原生
    var xhr = new XMLHttpRequest();
    xhr.open("GET", "http://codercba.com:1888/api/home/houselist?page=1", true);
    xhr.onreadystatechange = function () {
      if (xhr.readyState === 4 && xhr.status === 200) {
        console.log("Data retrieved successfully");
        console.log(xhr.responseText);
      }
    };
    xhr.send();

    // jquery
    /*
        $.ajax({
        url: "http://codercba.com:1888/api/home/houselist", // 请求的URL
        type: "GET", // 请求类型为GET
        data: {
            page: 1
        }, // 发送的数据

        success: function (data) { // 请求成功的回调函数
            console.log('已成功取得数据'); // 打印"123"
            console.log(data); // 打印返回的数据
        },
    });

*/


  })
})